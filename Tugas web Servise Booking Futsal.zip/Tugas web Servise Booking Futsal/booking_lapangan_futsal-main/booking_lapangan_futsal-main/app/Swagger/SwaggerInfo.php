<?php

namespace App\Swagger;

/**
 * @OA\Info(
 *     version="1.0.0",
 *     title="API Booking Lapangan Futsal",
 *     description="Dokumentasi API aplikasi Booking Lapangan Futsal",
 *     @OA\Contact(
 *         email="your-email@example.com"
 *     )
 * )
 */
class SwaggerInfo
{
    // Class kosong hanya untuk anotasi
}
